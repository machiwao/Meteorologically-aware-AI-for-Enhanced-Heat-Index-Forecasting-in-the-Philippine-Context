import Dashboard from './components/pages/Dashboard';

function App() {
  return <Dashboard />;
}

export default App;
