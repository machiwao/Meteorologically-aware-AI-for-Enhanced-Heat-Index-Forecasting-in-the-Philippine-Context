import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

const data = [
  { name: "Not Hazardous", value: 1 },
  { name: "Caution", value: 2 },
  { name: "Extreme Caution", value: 3 },
  { name: "Danger", value: 4 },
];

const colors = ["#4CAF50", "#FFC107", "#FF5722", "#D32F2F"];

export default function PieChartCard() {
  return (
    <div className="w-full h-48">S
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie data={data} dataKey="value" outerRadius={60}>
            {data.map((_, i) => (
              <Cell fill={colors[i]} key={i} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
