import LineChartCard from "./LineChartCard";
import PieChartCard from "./PiechartCard";
import StationTable from "./StationTable";

export default function RightPanel() {
  return (
    <div className="w-96 bg-white rounded-xl shadow p-4 flex flex-col gap-4">
      
      {/* Today's heat index */}
      <div className="bg-red-100 border-l-4 border-red-500 p-4 rounded">
        <h2 className="font-bold text-lg">Today</h2>
        <div className="text-4xl font-extrabold text-red-600">44°C</div>
        <div className="text-sm text-red-700">Danger (41° – 54°C)</div>
      </div>

      <LineChartCard />

      <StationTable />

      <PieChartCard />

      {/* Model metrics */}
      <div className="grid grid-cols-4 text-center border-t pt-3 text-sm">
        <div>RMSE<br/><b>2.1</b></div>
        <div>MAE<br/><b>2.1</b></div>
        <div>R²<br/><b>2.1</b></div>
        <div>ACC.<br/><b>2.1</b></div>
      </div>
    </div>
  );
}
